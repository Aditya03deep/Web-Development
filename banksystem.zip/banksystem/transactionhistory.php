<!doctype html>
<html lang="en">
  <head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-giJF6kkoqNQ00vy+HMDP7azOuL0xtbfIcaT9wjKHr8RbDVddVHyTfAAsrekwKmP1" crossorigin="anonymous">

    <link rel="stylesheet" href="css/history.css">
  <title>TSF Bank</title>
  <script src="https://kit.fontawesome.com/c8e4d183c2.js" crossorigin="anonymous"></script>

  
<link href="https://fonts.googleapis.com/css2?family=Nunito+Sans:wght@600&family=Ubuntu:wght@700&display=swap" rel="stylesheet">
<style>
    @import url('https://fonts.googleapis.com/css2?family=Baloo+Bhai+2&family=Roboto:wght@300&display=swap');
  </style>
  </head>
  <body>
    <div class="circle"></div>
    <div class="circle1"></div>
    <div class="circle2"></div> 
    <!-- Navbar -->
  <nav class="navbar navbar-expand-lg navbar-dark bg-dark sticky-top">
    <div class="container-fluid">
      <a class="navbar-brand" href="index.php">

        <img src="img/tsf.png" alt="logo" style="width:40px;">
      </a>
      <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent"
        aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarSupportedContent">
        <ul class="navbar-nav me-auto mb-2 mb-lg-0">
          <li class="nav-item">
            <a class="nav-link active" aria-current="page" href=" index.php ">Home</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="#about">About</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="#services"> Services</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="contact.css">Contact</a>
          </li>
        </ul>
      </div>
    </div>
  </nav>
 

     <!-- Table -->
  <div class="container">
    <div class="titlebox">
        <div class="title"><h2 class="text-center pt-4" style="color : #fff;">Transaction History</h2></div>
    </div>
        
       <br>

    
       <div class="table-responsive-sm">
    <table class="table table-hover table-striped">
        <thead style="color : ;" class="table-light">
            <tr>
                <th>S.No.</th>
                <th>Sender</th>
                <th>Receiver</th>
                <th>Amount</th>
                <th>Date & Time</th>
            </tr>
        </thead>
        <tbody>
        <?php

include 'config.php';

$sql ="select * from transaction";

$query =mysqli_query($conn, $sql);

while($rows = mysqli_fetch_assoc($query))
{
?>
<tr style="color : #fff;">
            <td class="py-2"><?php echo $rows['sno']; ?></td>
            <td class="py-2"><?php echo $rows['sender']; ?></td>
            <td class="py-2"><?php echo $rows['receiver']; ?></td>
            <td class="py-2"><?php echo $rows['balance']; ?> </td>
            <td class="py-2"><?php echo $rows['datetime']; ?> </td>
                
        <?php
            }

        ?>
        </tbody>
    </table>

    </div>
</div>
<!-- End Table -->


<!-- Footer -->

<footer>
<!-- Social media links -->
    <div class="follow">
      <div class="social">
          <li><a href="#" class="social" ><img src="img\facebook.png" alt="" class="size"></a></li>
          <li><a href="#"><img src="img\linkedin.png" alt="" id="in" class="size"></a></li>
          <li><a href="#" class="social"><img src="img\twitter.png" alt="" class="size"></a></li>
          <li><a href="#" class="social"><img src="img\instagram.png" alt="" class="size"></a></li>
        <p class="text-copy">
           Copyright &copy; 2021 All rights reserved
        </p>
     </div>
  </footer>


  </body>
</html>
