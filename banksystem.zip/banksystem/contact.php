<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Contact Us</title>
    <!-- CSS -->
    <link rel="stylesheet" href="css\contact.css">

    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css2?family=Poppins&display=swap" rel="stylesheet">
</head>

<body>
    <section>
    <!-- Information -->
        <div class="container">
            <div class="contactinfo">
                <div>
                    <h2>Contact Info</h2>
                    <ul class="info">
                        <li>
                            <span><img src="3.png" alt=""></span>
                            <span>221 Baker's Streer<br>Holmes Area</span>
                        </li>
                        <li>
                            <span><img src="mail.png" alt=""></span>
                            <span>sherlockholmes@gmail.com</span>
                        </li>
                        <li>
                            <span><img src="call.png" alt=""></span>
                            <span>6203444808</span>
                        </li>

                    </ul>
                </div>

                <!-- Social media links -->
                <ul class="sci">
                    <li><a href="#"><img src="fb.png" alt=""></a></li>
                    <li><a href="#"><img src="twitter.png" alt=""></a></li>
                    <li><a href="#"><img src="insta.png" alt=""></a></li>
                    <li><a href="#"><img src="linked.png" alt=""></a></li>
                </ul>

            </div>

            <!-- Form -->
            <div class="contactform">
                <h2>Send a Message</h2>
                <div class="formbox">
                    <div class="inputbox w50">
                        <input type="text" name="" required>
                        <span>First Name</span>
                    </div>
                    <div class="inputbox w50">
                        <input type="text" name="" required>
                        <span>Last Name</span>
                    </div>
                    <div class="inputbox w50">
                        <input type="text" name="" required>
                        <span>Email</span>
                    </div>
                    <div class="inputbox w50">
                        <input type="text" name="" required>
                        <span>Mobile-no</span>
                    </div>
                    <div class="inputbox w100">
                        <textarea name="" required></textarea>
                        <span>Write your message here...</span>
                    </div>
                    <div class="inputbox w100">
                        <input type="submit" value="Send">

                    </div>
                </div>
            </div>
        </div>
    </section>
</body>

</html>