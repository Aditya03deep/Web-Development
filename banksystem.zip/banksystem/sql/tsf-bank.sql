-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Feb 2, 2021 at 7:01 PM
-- Server version: 10.4.14-MariaDB
-- PHP Version: 7.2.33

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `TSF_BANK`
--

-- --------------------------------------------------------

--
-- Table structure for table `transaction`
--

CREATE TABLE `transaction` (
  `sno` int(3) NOT NULL AUTO_INCREMENT,
  `sender` text NOT NULL,
  `receiver` text NOT NULL,
  `balance` int(8) NOT NULL,
  `datetime` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY(`sno`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(3) NOT NULL AUTO_INCREMENT,
  `name` text NOT NULL,
  `email` varchar(30) NOT NULL,
  `balance` int(8) NOT NULL,
  PRIMARY KEY(`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `users`
--

 INSERT INTO `users` (`id`, `name`, `email`, `balance`) VALUES
 (1, 'Aditya Deepak', 'adityadeepak007@gmail.com',800000 ),
 (2, 'Ashutosh Kumar', 'ashukum2000@gmail.com', 500000),
 (3, 'Jatin Bhardwaj', 'jatin03bhardwaj@gmail.com', 40000),
 (4, 'Akarsh Anind', 'anindakarsh17@gmail.com', 50000),
 (5, 'Varun brude', 'bvarun29@gmail.com', 300000),
 (6, 'Nikhilesh Thakur', 'thakurniks05@gmail.com', 200000),
 (7, 'Arpita Tripathy', 'choti21tripathy@gmail.com', 700000),
 (8, 'Ankita Singh', 'singhankita010@gmail.com', 300000),
 (9, 'Vaishnavi Bhavya', 'vaishu023@gmail.com', 60000),
 (10, 'Tinu Shekhar', 'shekhar31tinu@gmail.com', 100000);

COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

--




