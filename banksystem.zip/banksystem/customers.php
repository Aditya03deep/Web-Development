 <!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User List</title>
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="css\customers.css">
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css2?family=Vollkorn&display=swap" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-giJF6kkoqNQ00vy+HMDP7azOuL0xtbfIcaT9wjKHr8RbDVddVHyTfAAsrekwKmP1" crossorigin="anonymous">
</head>
<body>
   <section>
        <?php
            include 'config.php';
            $sql = "SELECT * FROM users";
            $result = mysqli_query($conn,$sql);
        ?>
        <!-- Divs for background -->
        <div class="circle"></div>
        <div class="circle1"></div>
        <div class="circle2"></div>

        <!-- NAV-BAR -->
        <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
          <div class="container-fluid">
            <a class="navbar-brand" href="index.php"><img src="img\tsf.png" alt="" id="logo"></a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
              <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarSupportedContent">
              <ul class="navbar-nav me-auto mb-2 mb-lg-0">
              <li class="nav-item">
                  <a class="nav-link active" href="index.php">Home</a>
                </li>
                <li class="nav-item">
                  <a class="nav-link " aria-current="page" href="services.php">Services</a>
                </li>
                <li class="nav-item">
                  <a class="nav-link" href="transactionhistory.php">Transaction History</a>
                </li>
                <li class="nav-item">
                  <a class="nav-link" href="contact.php">Contact us</a>
                </li>
                
              </ul>
            </div>
          </div>
        </nav>
      </section>

      <!-- Table -->
      <section class="header">
          <div class="box">
            <h1>USER LIST</h1>
          </div>
          <div>
            <table class="table table-striped table-dark" id="table">
                  <thead>
                    <tr>
                      <th scope="col" width="10%">Id</th>
                      <th scope="col" width="15%">Name</th>
                      <th scope="col" width="22%">Email</th>
                      <th scope="col" width="">Balance</th>
                      <th scope="col" width="">Operation</th>
                    </tr>
                  </thead>
                  <tbody>
                      <?php
                        while($rows=mysqli_fetch_assoc($result)){
                      ?>
                       <tr>
                        <td><?php echo $rows['id'] ?></td>
                        <td><?php echo $rows['name']?></td>
                        <td><?php echo $rows['email']?></td>
                        <td><?php echo $rows['balance']?></td>
                        <td><a href="transaction.php?id= <?php echo $rows['id'] ;?>"> <button type="button" class="sendbtn">View Profile</button></a></td> 
                    </tr>
                <?php
                    }
                ?>
              </tbody>
            </table>
            </div>

      </section>
</body>
</html> 