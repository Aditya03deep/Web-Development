<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>TSF Bank</title>
    <link rel="stylesheet" href="css\index.css">
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300&display=swap" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-giJF6kkoqNQ00vy+HMDP7azOuL0xtbfIcaT9wjKHr8RbDVddVHyTfAAsrekwKmP1" crossorigin="anonymous">
</head>
<body>
<section>
        <div class="circle"></div>
        <div class="circle1"></div>
        <div class="circle2"></div>
        <header>
        <!-- LOGO of the website -->
            <img src="img\tsf.png" alt="" class="logo">
            <!-- NAV-BAR -->
            <ul>
                <li><a href="index.php" class="nav">Home</a></li>
                <li><a href="index.php" class="nav">About us</a></li>
                <li><a href="services.php" class="nav">Services</a></li>
                <li><a href="customers.php" class="nav">View all customers</a></li>
                <li><a href="contact.php" class="nav">Contact us</a></li>
            </ul>
        </header>
        <!-- Content box -->
        <div class="content">
            <div class="textbox">
                <h2>The Spark's Foundation <br> <span>BANK</span></h2>
                <p>TSF BANK was formed in 2021 at the initiative of the World Bank, the Government of India and representatives of Indian industry. The principal objective was to create a development financial institution for providing medium-term and long-term project financing to Indian businesses.</p>
                <a href="#" id="learn">Learn More</a>
            </div>
            <div>
            <!-- Social Media links -->
                <ul class="sci">
                    <li><a href="#" class="social" ><img src="img\facebook.png" alt="" class="size"></a></li>
                    <li><a href="#"><img src="img\linkedin.png" alt="" id="in" class="size"></a></li>
                    <li><a href="#" class="social"><img src="img\twitter.png" alt="" class="size"></a></li>
                    <li><a href="#" class="social"><img src="img\instagram.png" alt="" class="size"></a></li>
                </ul>
            </div>

        </div>
    </section>

</body>

</html>